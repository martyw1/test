import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Shield, CheckCircle, XCircle, Search, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Insurance() {
  const [selectedPatient, setSelectedPatient] = useState("");
  const [selectedInsurance, setSelectedInsurance] = useState("");
  const [verificationResults, setVerificationResults] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: patients } = useQuery({
    queryKey: ["/api/patients"],
    queryFn: async () => {
      const response = await fetch("/api/patients", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (!response.ok) throw new Error("Failed to fetch patients");
      return response.json();
    },
  });

  const { data: insuranceProviders } = useQuery({
    queryKey: ["/api/insurance/providers"],
    queryFn: async () => {
      const response = await fetch("/api/insurance/providers", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (!response.ok) throw new Error("Failed to fetch insurance providers");
      return response.json();
    },
  });

  const { data: patientInsurance } = useQuery({
    queryKey: ["/api/patients", selectedPatient, "insurance"],
    queryFn: async () => {
      if (!selectedPatient) return [];
      const response = await fetch(`/api/patients/${selectedPatient}/insurance`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (!response.ok) throw new Error("Failed to fetch patient insurance");
      return response.json();
    },
    enabled: !!selectedPatient,
  });

  const verifyMutation = useMutation({
    mutationFn: async ({ patientId, insuranceId }: { patientId: string; insuranceId: string }) => {
      const response = await apiRequest("POST", "/api/insurance/verify", {
        patientId: parseInt(patientId),
        insuranceId: parseInt(insuranceId),
      });
      return response.json();
    },
    onSuccess: (data) => {
      setVerificationResults(data);
      toast({
        title: "Verification Complete",
        description: "Insurance verification completed successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Verification Failed",
        description: "Failed to verify insurance coverage",
        variant: "destructive",
      });
    },
  });

  const handleVerify = () => {
    if (!selectedPatient || !selectedInsurance) {
      toast({
        title: "Selection Required",
        description: "Please select both patient and insurance",
        variant: "destructive",
      });
      return;
    }
    verifyMutation.mutate({
      patientId: selectedPatient,
      insuranceId: selectedInsurance,
    });
  };

  const getStatusIcon = (isValid: boolean, isActive: boolean) => {
    if (isValid && isActive) {
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    } else if (isValid && !isActive) {
      return <AlertCircle className="h-5 w-5 text-yellow-500" />;
    } else {
      return <XCircle className="h-5 w-5 text-red-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Insurance Verification</h2>
          <p className="text-gray-600">Verify patient insurance coverage and benefits</p>
        </div>
      </div>

      {/* Verification Form */}
      <Card className="healthcare-card">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Shield className="h-5 w-5 mr-2 text-blue-600" />
            Insurance Verification
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Select Patient
              </label>
              <Select value={selectedPatient} onValueChange={setSelectedPatient}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose patient" />
                </SelectTrigger>
                <SelectContent>
                  {patients?.map((patient: any) => (
                    <SelectItem key={patient.id} value={patient.id.toString()}>
                      {patient.firstName} {patient.lastName} - {patient.patientId}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Select Insurance
              </label>
              <Select 
                value={selectedInsurance} 
                onValueChange={setSelectedInsurance}
                disabled={!selectedPatient}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choose insurance" />
                </SelectTrigger>
                <SelectContent>
                  {patientInsurance?.map((insurance: any) => (
                    <SelectItem key={insurance.id} value={insurance.id.toString()}>
                      {insurance.memberId} - {insurance.insuranceProvider?.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex justify-end">
            <Button
              onClick={handleVerify}
              disabled={!selectedPatient || !selectedInsurance || verifyMutation.isPending}
              className="healthcare-button-primary"
            >
              {verifyMutation.isPending ? "Verifying..." : "Verify Coverage"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Verification Results */}
      {verificationResults && (
        <Card className="healthcare-card">
          <CardHeader>
            <CardTitle className="flex items-center">
              {getStatusIcon(verificationResults.isValid, verificationResults.isActive)}
              <span className="ml-2">Verification Results</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Coverage Status</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Valid Coverage:</span>
                    <Badge variant={verificationResults.isValid ? "default" : "destructive"}>
                      {verificationResults.isValid ? "Yes" : "No"}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Active Status:</span>
                    <Badge variant={verificationResults.isActive ? "default" : "destructive"}>
                      {verificationResults.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Prior Auth Required:</span>
                    <Badge variant={verificationResults.priorAuthRequired ? "secondary" : "default"}>
                      {verificationResults.priorAuthRequired ? "Yes" : "No"}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Member Status:</span>
                    <span className="text-sm font-medium">{verificationResults.memberStatus}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Coverage Details</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Deductible:</span>
                    <span className="text-sm font-medium">${verificationResults.coverageDetails.deductible}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Copay:</span>
                    <span className="text-sm font-medium">${verificationResults.coverageDetails.copay}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Coinsurance:</span>
                    <span className="text-sm font-medium">{verificationResults.coverageDetails.coinsurance}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Out of Pocket Max:</span>
                    <span className="text-sm font-medium">${verificationResults.coverageDetails.outOfPocketMax}</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Message:</strong> {verificationResults.message}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Insurance Providers */}
      <Card className="healthcare-card">
        <CardHeader>
          <CardTitle>Supported Insurance Providers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Provider Name</TableHead>
                  <TableHead>Code</TableHead>
                  <TableHead>Contact Info</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {insuranceProviders?.map((provider: any) => (
                  <TableRow key={provider.id}>
                    <TableCell className="font-medium">{provider.name}</TableCell>
                    <TableCell>{provider.code}</TableCell>
                    <TableCell>
                      {provider.contactInfo?.phone || "N/A"}
                    </TableCell>
                    <TableCell>
                      <Badge variant={provider.isActive ? "default" : "secondary"}>
                        {provider.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
