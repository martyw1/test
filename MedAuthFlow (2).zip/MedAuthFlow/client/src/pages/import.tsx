import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { 
  Upload, 
  FileText, 
  Users, 
  Shield, 
  CheckCircle, 
  AlertCircle,
  Download
} from "lucide-react";

export default function ImportPage() {
  const { toast } = useToast();
  
  // Persist state using sessionStorage to prevent reset on navigation
  const getStoredState = (key: string, defaultValue: any) => {
    try {
      const stored = sessionStorage.getItem(`import_${key}`);
      return stored ? JSON.parse(stored) : defaultValue;
    } catch {
      return defaultValue;
    }
  };
  
  const setStoredState = (key: string, value: any) => {
    try {
      sessionStorage.setItem(`import_${key}`, JSON.stringify(value));
    } catch {
      // Ignore storage errors
    }
  };
  
  const [uploadProgress, setUploadProgress] = useState(() => getStoredState('progress', 0));
  const [isUploading, setIsUploading] = useState(() => getStoredState('uploading', false));
  const [uploadResults, setUploadResults] = useState(() => getStoredState('results', null));

  const handleFileUpload = async (file: File, type: string, updateExisting = false) => {
    const newIsUploading = true;
    const newProgress = 0;
    const newResults = null;
    
    setIsUploading(newIsUploading);
    setUploadProgress(newProgress);
    setUploadResults(newResults);
    
    // Store state immediately
    setStoredState('uploading', newIsUploading);
    setStoredState('progress', newProgress);
    setStoredState('results', newResults);
    
    try {
      // Read file content
      const formData = new FormData();
      formData.append('file', file);
      formData.append('type', type);
      formData.append('updateExisting', updateExisting.toString());

      // Update progress incrementally
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          const newProg = Math.min(prev + 5, 90);
          setStoredState('progress', newProg);
          return newProg;
        });
      }, 200);

      const response = await fetch('/api/import/process', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: formData,
      });

      clearInterval(progressInterval);
      const finalProgress = 100;
      setUploadProgress(finalProgress);
      setStoredState('progress', finalProgress);

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Import failed');
      }

      const result = await response.json();
      const resultData = {
        type,
        fileName: file.name,
        recordsProcessed: result.recordsProcessed,
        recordsImported: result.recordsImported,
        recordsUpdated: result.recordsUpdated || 0,
        duplicatesSkipped: result.duplicatesSkipped || 0,
        errors: result.errors,
        errorDetails: result.errorDetails || [],
        duplicates: result.duplicates || [],
        updates: result.updates || [],
        updateExisting
      };
      
      setUploadResults(resultData);
      setStoredState('results', resultData);

      const successCount = result.recordsImported + (result.recordsUpdated || 0);
      toast({
        title: "Import Complete",
        description: `${file.name} processed: ${successCount} records processed successfully.`,
      });
    } catch (error: any) {
      console.error('Import error:', error);
      toast({
        title: "Import Failed",
        description: error.message || "Failed to process file.",
        variant: "destructive",
      });
    } finally {
      const finalUploading = false;
      setIsUploading(finalUploading);
      setStoredState('uploading', finalUploading);
    }
  };

  // Clear stored state when user wants to start fresh
  const clearImportState = () => {
    setUploadProgress(0);
    setIsUploading(false);
    setUploadResults(null);
    setStoredState('progress', 0);
    setStoredState('uploading', false);
    setStoredState('results', null);
  };

  const PatientImportCard = () => (
    <Card className="healthcare-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          EMR Patient Records Import
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Supports HL7 FHIR R4, CCD (C-CDA), and CSV formats. Ensure patient data includes required fields: MRN, demographics, and insurance information.
          </AlertDescription>
        </Alert>

        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
          <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 mb-2">Upload EMR Patient Records</p>
          <p className="text-sm text-gray-500 mb-4">
            Accepted formats: .xml (HL7 FHIR), .xml (CCD), .csv (Max 100MB)
          </p>
          <input
            type="file"
            accept=".xml,.csv"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleFileUpload(file, "patients");
            }}
            className="hidden"
            id="patient-upload"
          />
          <label htmlFor="patient-upload">
            <Button asChild variant="outline">
              <span>Select Patient File</span>
            </Button>
          </label>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">Supported Patient Data Fields:</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Medical Record Number (MRN)</li>
            <li>• Demographics (Name, DOB, Gender, Address)</li>
            <li>• Contact Information (Phone, Email)</li>
            <li>• Insurance Information (Primary/Secondary)</li>
            <li>• Emergency Contact Details</li>
            <li>• Medical History and Allergies</li>
          </ul>
        </div>

        <Button 
          variant="outline" 
          className="w-full"
          onClick={() => {
            const link = document.createElement('a');
            link.href = '/templates/patient-import-template.csv';
            link.download = 'patient-import-template.csv';
            link.click();
          }}
        >
          <Download className="h-4 w-4 mr-2" />
          Download CSV Template
        </Button>
      </CardContent>
    </Card>
  );

  const AuthorizationImportCard = () => (
    <Card className="healthcare-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Authorization Data Import
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Supports X12 278 (Authorization Request/Response), HL7 FHIR Coverage, and CSV formats for prior authorization data.
          </AlertDescription>
        </Alert>

        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
          <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 mb-2">Upload Authorization Records</p>
          <p className="text-sm text-gray-500 mb-4">
            Accepted formats: .edi (X12), .xml (HL7 FHIR), .csv (Max 50MB)
          </p>
          <input
            type="file"
            accept=".edi,.xml,.csv"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleFileUpload(file, "authorizations");
            }}
            className="hidden"
            id="auth-upload"
          />
          <label htmlFor="auth-upload">
            <Button asChild variant="outline">
              <span>Select Authorization File</span>
            </Button>
          </label>
        </div>

        <div className="bg-green-50 p-4 rounded-lg">
          <h4 className="font-medium text-green-900 mb-2">Supported Authorization Fields:</h4>
          <ul className="text-sm text-green-800 space-y-1">
            <li>• Authorization ID and Reference Numbers</li>
            <li>• Patient MRN and Demographics</li>
            <li>• Insurance Provider and Policy Information</li>
            <li>• Service/Procedure Codes (CPT, HCPCS)</li>
            <li>• Diagnosis Codes (ICD-10)</li>
            <li>• Authorization Status and Dates</li>
            <li>• Clinical Justification and Notes</li>
          </ul>
        </div>

        <Button 
          variant="outline" 
          className="w-full"
          onClick={() => {
            const link = document.createElement('a');
            link.href = '/templates/authorization-import-template.csv';
            link.download = 'authorization-import-template.csv';
            link.click();
          }}
        >
          <Download className="h-4 w-4 mr-2" />
          Download CSV Template
        </Button>
      </CardContent>
    </Card>
  );

  const UploadProgressCard = () => (
    isUploading && (
      <Card className="healthcare-card">
        <CardHeader>
          <CardTitle>Upload Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <Progress value={uploadProgress} className="mb-2" />
          <p className="text-sm text-gray-600">Uploading and processing file... {uploadProgress}%</p>
        </CardContent>
      </Card>
    )
  );

  const UploadResultsCard = () => (
    uploadResults && (
      <Card className="healthcare-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Import Results
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-gray-600">File Name</p>
              <p className="font-medium">{uploadResults.fileName}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Import Type</p>
              <p className="font-medium capitalize">{uploadResults.type}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Records Processed</p>
              <p className="font-medium">{uploadResults.recordsProcessed}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">New Records Imported</p>
              <p className="font-medium text-green-600">{uploadResults.recordsImported}</p>
            </div>
            {uploadResults.recordsUpdated > 0 && (
              <div>
                <p className="text-sm text-gray-600">Records Updated</p>
                <p className="font-medium text-blue-600">{uploadResults.recordsUpdated}</p>
              </div>
            )}
            {uploadResults.duplicatesSkipped > 0 && (
              <div>
                <p className="text-sm text-gray-600">Duplicates Skipped</p>
                <p className="font-medium text-yellow-600">{uploadResults.duplicatesSkipped}</p>
              </div>
            )}
          </div>

          {uploadResults.duplicates && uploadResults.duplicates.length > 0 && !uploadResults.updateExisting && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="space-y-2">
                <p>{uploadResults.duplicates.length} duplicate records found with changes. These were skipped to prevent data loss.</p>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    const fileInput = document.querySelector(`#${uploadResults.type === 'patients' ? 'patient' : 'auth'}-upload`) as HTMLInputElement;
                    if (fileInput?.files?.[0]) {
                      handleFileUpload(fileInput.files[0], uploadResults.type, true);
                    }
                  }}
                >
                  Re-import and Update Existing Records
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {uploadResults.duplicates && uploadResults.duplicates.length > 0 && (
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h4 className="font-medium text-yellow-900 mb-2">Duplicate Records Found:</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {uploadResults.duplicates.slice(0, 5).map((dup: any, index: number) => (
                  <div key={index} className="text-sm text-yellow-800 bg-white p-2 rounded border">
                    <p><strong>Row {dup.rowNumber}:</strong> {dup.existing.name} (ID: {dup.existing.patientId})</p>
                    <p className="text-xs">Changes detected in: {Object.entries(dup.changes).filter(([_, changed]) => changed).map(([field, _]) => field).join(', ')}</p>
                  </div>
                ))}
                {uploadResults.duplicates.length > 5 && (
                  <p className="text-sm text-yellow-700">... and {uploadResults.duplicates.length - 5} more duplicates</p>
                )}
              </div>
            </div>
          )}

          {uploadResults.updates && uploadResults.updates.length > 0 && (
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Records Updated:</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {uploadResults.updates.slice(0, 5).map((upd: any, index: number) => (
                  <div key={index} className="text-sm text-blue-800 bg-white p-2 rounded border">
                    <p><strong>Row {upd.rowNumber}:</strong> {upd.existing.name} (ID: {upd.existing.patientId})</p>
                    <p className="text-xs">Updated: {Object.entries(upd.changes).filter(([_, changed]) => changed).map(([field, _]) => field).join(', ')}</p>
                  </div>
                ))}
                {uploadResults.updates.length > 5 && (
                  <p className="text-sm text-blue-700">... and {uploadResults.updates.length - 5} more updates</p>
                )}
              </div>
            </div>
          )}

          {uploadResults.errors > 0 && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {uploadResults.errors} records had errors and were not imported. 
                <Button variant="link" className="p-0 ml-1">View error log</Button>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>
    )
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Data Import</h1>
        <p className="text-gray-600 mt-1">Import patient records and authorization data from external systems</p>
      </div>

      <Tabs defaultValue="patients" className="space-y-6">
        <TabsList>
          <TabsTrigger value="patients">Patient Records</TabsTrigger>
          <TabsTrigger value="authorizations">Authorization Data</TabsTrigger>
        </TabsList>

        <TabsContent value="patients" className="space-y-6">
          <PatientImportCard />
          <UploadProgressCard />
          <UploadResultsCard />
          {(uploadResults || isUploading || uploadProgress > 0) && (
            <Card className="healthcare-card border-orange-200">
              <CardContent className="pt-6">
                <Button 
                  variant="outline" 
                  onClick={clearImportState}
                  className="w-full"
                >
                  Clear Import State & Start Fresh
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="authorizations" className="space-y-6">
          <AuthorizationImportCard />
          <UploadProgressCard />
          <UploadResultsCard />
        </TabsContent>
      </Tabs>
    </div>
  );
}